var ws = new WebSocket("ws://localhost:8181");

ws.onopen = function(e){
    console.log('Conexión hacia el servidor abierta');
};

ws.onmessage = function(message){
    console.log('Recibo resultado');
    console.log(message.data);
    document.getElementById('valor_resultado').innerHTML = message.data;
}

function btnOperacion(){
    let operacion_id = document.getElementById("operacion_id").value;
    let numero_uno = document.getElementById("numero_uno").value;
    let numero_dos = document.getElementById("numero_dos").value;
    const data = {
        operacion_id: operacion_id,
        numero_uno: numero_uno,
        numero_dos: numero_dos
    }
    ws.send(JSON.stringify(data));
}