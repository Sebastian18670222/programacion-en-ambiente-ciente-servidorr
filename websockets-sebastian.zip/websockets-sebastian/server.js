var WebSocketServer = require('ws').Server,
wss = new WebSocketServer({port:8181});

console.log('Servidor iniciado');
wss.on('connection', function(ws){
    console.log('Cliente conectado');
    ws.on('message', function(message){
        var object = JSON.parse(message);
        if(object.operacion_id == 1){
            console.log('Realizando suma');
            var resultado = parseFloat(object.numero_uno)+parseFloat(object.numero_dos);
            resultado = resultado.toFixed(2);
            ws.send(resultado);
        }
        if(object.operacion_id == 2){
            console.log('Realizando resta');
            var resultado = object.numero_uno - object.numero_dos;
            resultado = resultado.toFixed(2);
            ws.send(resultado);
        }
        if(object.operacion_id == 3){
            console.log('Realizando multiplicacion');
            var resultado = object.numero_uno * object.numero_dos;
            resultado = resultado.toFixed(2);
            ws.send(resultado);
        }
        if(object.operacion_id == 4){
            console.log('Realizando division');
            var resultado = object.numero_uno / object.numero_dos;
            resultado = resultado.toFixed(2);
            ws.send(resultado);
        }
    });
});